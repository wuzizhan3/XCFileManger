//
//  XCAlertView.swift
//  fileMangerDemo
//
//  Created by qf2 on 2017/2/6.
//  Copyright © 2017年 wxc94998. All rights reserved.
//

import UIKit

class XCAlertView : NSObject{
    
    static func popNormalAlertView(title : String , message : String , left : String , right : String) -> Void {
    
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction.init(title: left, style: .cancel, handler: { (left) in
            
        }))
        
        alert.addAction(UIAlertAction.init(title: right, style: .cancel, handler: { (right) in
            
        }))
        
        self.currentViewController().present(alert, animated: true) {
            
        }
        
    }
    
    
    
    static func popNormalOneAlertView(title : String , message : String , left : String ) -> Void {
        
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction.init(title: left, style: .cancel, handler: { (left) in
            
        }))
        
        self.currentViewController().present(alert, animated: true, completion: nil)
        
    }
    
    
    static func popTextFieldAlertView(title : String , message : String , left : String ) -> Void {
        
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction.init(title: left, style: .cancel, handler: { (left) in
            
        }))
        
        alert.addTextField { (text) in
            
        }
        
        self.currentViewController().present(alert, animated: true) {
            
        }
        
    }
    
    
   static func currentWindow() -> UIWindow {
        
        var currwindow = UIApplication.shared.keyWindow! as UIWindow
        
        if currwindow.windowLevel != UIWindowLevelNormal {
            
            let windowArray = UIApplication.shared.windows as NSArray
            
            for enumobject in windowArray {
                
                if (enumobject as! UIWindow).windowLevel == UIWindowLevelNormal {
                    
                    currwindow = enumobject as! UIWindow
                    
                    break
                }
                
            }
            
        }
        
        return currwindow
        
    }
    
   static func currentViewController() -> UIViewController {
        
        let current = self.currentWindow().rootViewController
        
        let present = current?.presentedViewController
        
        if (present != nil) {
            
            return present!
            
        }
        
        return current!
        
    }
    
    
    
}

//
//  PreviewViewController.swift
//  fileMangerDemo
//
//  Created by qf2 on 2017/2/7.
//  Copyright © 2017年 wxc94998. All rights reserved.
//

import UIKit

class PreviewViewController: UIViewController,UIDocumentInteractionControllerDelegate {

    var documentview : UIDocumentInteractionController!
    var ObjectModel : MKFileObject?
    
    
    init(objcet : MKFileObject) {
        
        super.init(nibName: nil, bundle: nil)
        
        self.ObjectModel = objcet
        
    }
    
    deinit {
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if ((self.ObjectModel?.filePath) != nil) && FileManager.default.fileExists(atPath: (self.ObjectModel?.filePath)!) {
            
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now(), execute: { 
                

                
            })
            
        }
        
        print(self.ObjectModel?.filePath! as Any)
        
        let waitmessage = UILabel.init()
        
        waitmessage.text = "正在加载中..."
        
        waitmessage.textColor = UIColor.gray
        
        waitmessage.textAlignment = NSTextAlignment.center
        
        waitmessage.numberOfLines = 0
        
        waitmessage.frame = self.view.frame
        
        //waitmessage.font = UIFont.boldSystemFont(ofSize: 35)
        
        waitmessage.font = UIFont.init(name: "Bradley Hand", size: 35)
        
        self.view.addSubview(waitmessage)
        
        self.view.backgroundColor = UIColor.white
        
        self.documentview = UIDocumentInteractionController.init(url: URL.init(fileURLWithPath: (self.ObjectModel?.filePath)!))
        
        self.documentview.delegate = self
        
        if !self.documentview.presentPreview(animated: true) {
            
            waitmessage.font = UIFont.init(name: "Menlo-Regular", size: 20)
            
            let fileAttributes = try! FileManager.default.attributesOfItem(atPath: (self.ObjectModel?.filePath)!)
            
                print(fileAttributes[FileAttributeKey.size]!)
            
            let size = fileAttributes[FileAttributeKey.size] as! Float
            
            waitmessage.text = "文件名: " + (self.ObjectModel?.name)!
            
            if size < 1024 {
                waitmessage.text = waitmessage.text! + "\n" + "文件大小: " + "size" + "B"
            }
            
            if (1024 <= size) && (size < 1048576) {
                
                waitmessage.text = waitmessage.text! + "\n" +  String.init(format: "文件大小: "+"%0.1f"+"KB", size/1024)
                
            }
            
            if 1048576 <= size {
                
                waitmessage.text = waitmessage.text! + "\n" +  String.init(format: "文件大小: " + "%0.1f" + "M", size/(1024*1024))
                
            }
            
            let filetime = fileAttributes[FileAttributeKey.modificationDate]
            
            let datefrom = DateFormatter.init()
            
            datefrom.dateFormat = "MM-dd HH:mm:ss"
            
            waitmessage.text = waitmessage.text! + "\n" + "创建时间: " + datefrom.string(from: filetime as! Date)
            
            
            waitmessage.text = waitmessage.text! + "\n\n" + "暂不支持查看该类型的文件"
            
        }
        

        // Do any additional setup after loading the view.
    }
    
    
    
    override func viewWillDisappear(_ animated: Bool) {
        
        self.documentview = nil
        
    }
    
    
    func documentInteractionControllerViewForPreview(_ controller: UIDocumentInteractionController) -> UIView? {
        
        return self.view
        
    }
    
    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController {
        
        return self
        
    }
    
    func documentInteractionControllerDidEndPreview(_ controller: UIDocumentInteractionController) {
        
        self.documentview = nil
        
        self.navigationController?.popViewController(animated: true)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  ViewController.swift
//  fileMangerDemo
//
//  Created by qf2 on 2017/2/4.
//  Copyright © 2017年 wxc94998. All rights reserved.
//

import UIKit
import Photos


struct Screensize {
    
    let width = UIScreen.main.bounds.size.width
    
    let height = UIScreen.main.bounds.size.height
    
}

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    var mycollection : UICollectionView?
    var datasourceArray : NSMutableArray!
    let Homepath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
    var filepath : String!
    var backbtn : UIBarButtonItem!
    let fixedleng = Screensize.init().width/4
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        /// take a place
        
        self.excessOrimport()
        
        /// collection -> reload
        
        self.loadcollection()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       
        return datasourceArray.count
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = self.mycollection?.dequeueReusableCell(withReuseIdentifier: "cellid", for: indexPath)
        
        for view in (cell?.contentView.subviews)! {
           
            view.removeFromSuperview()
        }
        
        cell?.backgroundColor = UIColor.clear
        
        cell?.contentView.backgroundColor = UIColor.init(red:   CGFloat(arc4random_uniform(255))/255.0,
                                                         green: CGFloat(arc4random_uniform(255))/255.0,
                                                         blue:  CGFloat(arc4random_uniform(255))/255.0,
                                                         alpha: 1)
        
        cell?.contentView.layer.masksToBounds = true
        
        cell?.contentView.layer.cornerRadius = 5
        
        let label = UILabel.init()

        label.frame = CGRect.init(x: 0, y: 0, width: fixedleng, height: fixedleng)
        
        label.numberOfLines = 0

        label.textColor = UIColor.black
        
        label.textAlignment = NSTextAlignment.center
        
        cell?.contentView.addSubview(label)
        
        let imageviewWidth = (cell?.contentView.frame.size.width)!
        
        if datasourceArray.count > 0 {
            
            let ObjeceModel = datasourceArray.object(at: indexPath.item) as! MKFileObject
            
            switch ObjeceModel.fileType {
                
            case MKFileType.directory:
                
                label.text = ObjeceModel.name
                
                break
                
            case MKFileType.image:
                
                let image = UIImageView.init()
                
                image.frame = CGRect.init(x: 0, y: 0, width: imageviewWidth, height: imageviewWidth)
                
                image.image = ObjeceModel.image
                
                cell?.contentView.addSubview(image)
                
                break
                
            default:
                
                label.text = ObjeceModel.name
                
                break
               
            }
            
        }
        
        return cell!
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let ObjeceModel = datasourceArray.object(at: indexPath.item) as! MKFileObject
        
        if self.filepath != Homepath.first {
            
            self.navigationItem.leftBarButtonItem = nil
            
        }else{
            
            self.navigationItem.leftBarButtonItem = backbtn

        }
        
        switch ObjeceModel.fileType {
            
        case MKFileType.directory:
            
            self.filepath = self.filepath + "/" + ObjeceModel.name
            
            self.loadcollection()
        
            break
            
        case MKFileType.unknown:
            
            self.popQuickLock(ObjeceModel: ObjeceModel)
            
            break
            
        case MKFileType.image:
            
            self.popQuickLock(ObjeceModel: ObjeceModel)
            
            break
            
        case MKFileType.txt:
            
            self.popQuickLock(ObjeceModel: ObjeceModel)
            
            break
            
        default:
            
            XCAlertView.popNormalOneAlertView(title: "抱歉", message: "暂不支持查看该类型", left: "这样啊")

            break
        }
        
    }
    
    
    func popQuickLock(ObjeceModel : MKFileObject) -> Void {
        
        let preview = PreviewViewController.init(objcet: ObjeceModel)
        
        self.navigationController?.pushViewController(preview, animated: true)
        
    }
    
    
    func backaction() -> Void {
        
        if self.filepath == Homepath.first {
            
           XCAlertView.popNormalOneAlertView(title: "叫爸爸", message: "哎", left: "X")
                    
        }else{
           
            self.filepath = (self.filepath as NSString).deletingLastPathComponent
            
            if self.filepath == Homepath.first {
                
                self.navigationItem.leftBarButtonItem = nil
            }
            
            self.loadcollection()
            
        }
       
    }
    
    
    func loadcollection() -> Void {
        
        datasourceArray.removeAllObjects()
        
        let filemanager = FileManager.default
        
        let patharray = filemanager.subpaths(atPath: self.filepath!)
        
     ///   print(patharray!,self.filepath)
        
        for string in patharray! {
            
            let ObjeceModel = MKFileObject.init(filePath:self.filepath + "/" + string)
            
      //      print(self.filepath + "/" + string)
            
            datasourceArray.add(ObjeceModel!)
        }
        
     ///   print((datasourceArray.lastObject as! MKFileObject).fileType)
        
        self.mycollection?.reloadData()
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
    
    }
    
    func rightbtnAddAction() -> Void {
        
        let alert = UIAlertController.init(title: "菜单", message: "选择", preferredStyle: .alert)
        
        weak var weakself  = self
        
        alert.addAction(UIAlertAction.init(title: "新建文件夹", style: .default, handler: { (void) in
            
            let newFolderAlert = UIAlertController.init(title: "填写文件夹的名字", message: "请填写创建的文件夹的名字", preferredStyle: .alert)
            
            newFolderAlert.addAction(UIAlertAction.init(title: "取消", style: .cancel, handler: { (void) in
                
            }))
            
           
            
            newFolderAlert.addAction(UIAlertAction.init(title: "创建", style: .destructive, handler: { (void) in
                
                let newfilename = newFolderAlert.textFields?.first?.text
                
                let newFilePath = self.filepath + "/" + newfilename!
                
                FileManager.default.fileExists(atPath: newFilePath) ? nil : try? FileManager.default.createDirectory(atPath: newFilePath, withIntermediateDirectories: true, attributes: nil)
                
                weakself?.loadcollection()
                
            }))
            
            newFolderAlert.addTextField(configurationHandler: { (textfield) in
                
            })
            
            self.present(newFolderAlert, animated: true, completion: { 
                
            })
            
        }))
        let imagepick = UIImagePickerController.init()
        
        imagepick.delegate = self
        
        alert.addAction(UIAlertAction.init(title: "相册", style: .default, handler: { (void) in
            
            imagepick.sourceType = UIImagePickerControllerSourceType.photoLibrary
            
            weakself?.present(imagepick, animated: true, completion: nil)
            
        }))
        
        alert.addAction(UIAlertAction.init(title: "相机", style: .default, handler: { (void) in
            
            imagepick.sourceType = UIImagePickerControllerSourceType.camera
            
            weakself?.present(imagepick, animated: true, completion: nil)
            
        }))
        
        alert.addAction(UIAlertAction.init(title: "取消", style: .destructive, handler: { (void) in
            
        }))
        
        self.present(alert, animated: true) { 
            
        }
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        self.dismiss(animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if picker.sourceType == UIImagePickerControllerSourceType.camera {
            
            let image = info[UIImagePickerControllerOriginalImage]
            
            let data = UIImageJPEGRepresentation(image as! UIImage, 1)
            
            FileManager.default.createFile(atPath: filepath + "/" + "\(NSDate.init())" + ".jpg", contents: data, attributes: nil)
            
            self.loadcollection()
            
        }else{
            
            let imageurl = info[UIImagePickerControllerReferenceURL]
            
            let fetchAsset = PHAsset.fetchAssets(withALAssetURLs: [imageurl as! URL], options: nil)
            let asset = fetchAsset.firstObject
            
            let assetResourceArray = PHAssetResource.assetResources(for: asset!)
            
            let assetResource = assetResourceArray.first
            
            let options = PHAssetResourceRequestOptions.init()
            
            options.isNetworkAccessAllowed = false
            
            PHAssetResourceManager.default().writeData(for: assetResource!, toFile: NSURL.init(fileURLWithPath: filepath + "/" + (assetResource?.originalFilename)!) as URL, options: options, completionHandler: { (error) in
                self.loadcollection()
            })
            
            
            
        }
        
        self.dismiss(animated: true, completion: nil)
        
    }
    
    
    func excessOrimport() -> Void {
        
        self.filepath = Homepath.first
        
        datasourceArray = NSMutableArray.init()
        
        self.view.backgroundColor = UIColor.orange
        
        self.navigationController?.isNavigationBarHidden = false
        
        self.navigationItem.title = "叫爸爸"
        
        backbtn = UIBarButtonItem.init(title: "back", style: .done, target: self, action: #selector(backaction))
        
        backbtn.tintColor = UIColor.blue
        
        let rightbtn = UIBarButtonItem.init(title: "✚", style: .done, target: self, action: #selector(rightbtnAddAction))
        
        rightbtn.tintColor = UIColor.black
        
        self.navigationItem.rightBarButtonItem = rightbtn
        
        
        let  layo = UICollectionViewFlowLayout()
        
        layo.scrollDirection = UICollectionViewScrollDirection.vertical
        
        layo.itemSize = CGSize.init(width: fixedleng, height: fixedleng)
        
        layo.sectionInset = UIEdgeInsets.init(top: fixedleng/4, left: fixedleng/4, bottom: fixedleng/4, right: fixedleng/4)
        
        mycollection = UICollectionView.init(frame: self.view.frame, collectionViewLayout: layo)
        
        self.view.addSubview(self.mycollection!)
        
        self.mycollection?.backgroundColor = UIColor.white
        
        self.mycollection?.delegate = self
        
        self.mycollection?.dataSource = self
        
        self.mycollection?.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cellid")
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

